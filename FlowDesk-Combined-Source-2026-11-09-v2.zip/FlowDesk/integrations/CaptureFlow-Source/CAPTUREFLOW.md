# CaptureFlow — a local capture fork of ShareX

Modified on 26 October 2026. Upstream: https://github.com/ShareX/ShareX, commit `125dc20dfd2944d95492ce7164f58b5f38ac4b1e` (22.0.0 development source).

CaptureFlow is a customized ShareX build, not an independently rewritten capture engine or an official ShareX release. Original copyright notices, GPL license, and third-party licenses are preserved. Changes use the same GPL terms as upstream.

## Changes

### Image editing update

- Clicking an image thumbnail with the default click behaviour, or its filename, opens a compact image menu with **Edit image — all tools** first. It also offers preview, copy and show-in-folder actions.
- Each completed, existing image has a direct **Edit image** button. It opens that image in the existing full editor, where drawing, text, crop, resize, blur, pixelate and effects can be applied without repeatedly loading tools from the main menu.
- The full right-click menu also puts editing first; Ctrl+E remains available. Ctrl/Shift multi-selection, drag-and-drop, custom thumbnail click preferences, and non-image file actions are retained. Working tasks and missing image files do not open an editor.
- Verified on a generated image: click-to-edit menu, combined rectangle and blur edits in one editor, and Ctrl+S saving changed pixels to the image while keeping the editor open. No user screenshots were used.

- Separate CaptureFlow executable, title, process mutex, pipe identity, and settings directory.
- Original CaptureFlow monitor/recording icon and a LOCAL CAPTURE title-bar badge.
- Uploads disabled in SystemOptions at each initialization, irrespective of stored preferences or registry values. Existing upstream IsUploadAllowed guards enforce the policy and disable upload menu actions. Upload destination and upload-task sections are removed from the main navigation.
- Automatic upstream updates disabled through the system policy. This prevents the fork silently replacing itself with an upstream build.
- Portable configuration and captures live in the CaptureFlow subfolder beside the executable. File associations are not registered on startup. Upstream first-run onboarding is skipped.
- Original screenshot, region capture, editor, recording, clipboard, history, and local tools are retained. Some individual dialogs still contain upstream names and credits.

## Build

Requires the .NET 10 SDK on Windows. From this source folder:

```powershell
dotnet publish .\ShareX\ShareX.csproj -c Release -p:Platform=x64 -r win-x64 --self-contained true -o .\publish
```

The distributed app includes the .NET runtime; users do not need to install the SDK.

## Source analysis

The repository is organized into separate application/workflow, capture, recording, image editor, history, tools, and upload projects. It uses an Avalonia interface with shared SkiaSharp image operations. This makes a source fork practical without rebuilding selection/editing behavior from scratch.

`ShareX.ScreenCaptureLib/Screenshot.cs` exposes full-screen, active-window, and rectangle capture. `RegionCaptureTasks.cs` and the presentation layer implement selection workflows. `ShareX.ImageEditor` handles annotation/editing; `ShareX.ImageEffectsLib` supplies image transformations. `ShareX.HistoryLib` uses SQLite-backed local history.

`ShareX.ScreenRecordingLib/RecordingOptions.cs` defines native H.264/AAC MP4 and GIF recording, frame rate, region/window selection, cursor, system/microphone audio, and camera overlay options. `ScreenRecorder.cs` owns preparation, recording, pause, completion, and cleanup. Video uses Windows graphics APIs and Media Foundation; hardware/driver availability affects recording. These are source-established capabilities, not a claim that every mode was tested on this PC.

`WorkerTask.cs` sequences work and gates upload jobs through `TaskHelpers.IsUploadAllowed()`. `MainMenuBuilder.cs` already supports system-level upload disablement. CaptureFlow uses that shared policy rather than only hiding upload buttons. `ApplicationSettingsRuntime.cs` respects the system update policy; `PersonalPathManager.cs` owns settings isolation.

This was ordinary source analysis. REA binary reverse engineering was not required. Review README-CaptureFlow.txt and verification.json in the app package for use and checks actually completed.
