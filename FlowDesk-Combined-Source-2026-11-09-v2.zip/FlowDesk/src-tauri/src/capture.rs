//! FlowDesk capture controls and local media index.
//! The ShareX-derived helper is a separately packaged component; media stays in Documents.
use serde::Serialize;
use std::{fs, path::PathBuf, process::{Child, Command, Stdio}, sync::{Mutex, OnceLock}};
use tauri::{AppHandle, Manager};

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CaptureItem { name: String, path: String, kind: String, modified: u64, size: u64 }

fn library() -> Result<PathBuf, String> {
    let profile = std::env::var_os("USERPROFILE").ok_or("Windows user profile could not be located")?;
    let base = PathBuf::from(profile).join("Documents");
    let root = base.join("FlowDesk Library");
    for dir in ["Captures", "Transcripts", "Imported"] { fs::create_dir_all(root.join(dir)).map_err(|e| e.to_string())?; }
    Ok(root)
}

fn helper(app: &AppHandle) -> Result<PathBuf, String> {
    let resource = app.path().resource_dir().map_err(|e| e.to_string())?;
    let candidates = [resource.join("CaptureFlow.exe"), resource.join("capture").join("CaptureFlow.exe")];
    candidates.into_iter().find(|p| p.is_file()).ok_or_else(|| "The capture helper is not installed. Reinstall FlowDesk from its complete Windows package.".into())
}

fn launch(app: &AppHandle, args: &[&str]) -> Result<(), String> {
    let exe = helper(app)?;
    let root = library()?;
    let config_dir = library()?.parent().ok_or("Documents folder could not be located")?.join("FlowDesk Capture");
    fs::create_dir_all(&config_dir).map_err(|e| e.to_string())?;
    let config_path = config_dir.join("ApplicationConfig.json");
    let mut config: serde_json::Value = fs::read(&config_path).ok().and_then(|b| serde_json::from_slice(&b).ok()).unwrap_or_else(|| serde_json::json!({}));
    config["ShowStartScreen"] = false.into(); config["DisableHotkeys"] = true.into(); config["ShowTray"] = false.into();
    config["SilentRun"] = true.into(); config["AutoCheckUpdate"] = false.into(); config["DisableUpload"] = true.into();
    config["UseCustomScreenshotsPath"] = true.into(); config["CustomScreenshotsPath"] = root.join("Captures").to_string_lossy().to_string().into();
    config["CustomScreenshotsPath2"] = "".into();
    config["DefaultTaskSettings"]["AfterCaptureJob"] = 256.into();
    config["DefaultTaskSettings"]["GeneralSettings"]["ShowToastNotificationAfterTaskCompleted"] = false.into();
    let mut cmd = Command::new(exe);
    cmd.current_dir(config_dir).arg("-silent").arg("-FlowDeskParent").arg(std::process::id().to_string()).args(args);
    fs::write(config_path, serde_json::to_vec_pretty(&config).map_err(|e| e.to_string())?).map_err(|e| e.to_string())?;
    cmd.spawn().map_err(|e| format!("Could not start capture helper: {e}"))?;
    Ok(())
}

static TRANSCRIBER: OnceLock<Mutex<Option<Child>>> = OnceLock::new();
fn sidecar(app: &AppHandle) -> Result<(PathBuf, PathBuf), String> {
    let dir = app.path().resource_dir().map_err(|e| e.to_string())?;
    let py = dir.join("python");
    let exe = py.join("python-runtime").join("python.exe");
    let script = py.join("transcribe_worker.py");
    if !exe.is_file() || !script.is_file() { return Err("The local transcription runtime is not installed. Use the complete FlowDesk package.".into()); }
    Ok((exe, py))
}

#[tauri::command]
pub fn capture_transcript_start(app: AppHandle, audio: String, language: String) -> Result<(), String> {
    if !["computer", "microphone", "both"].contains(&audio.as_str()) { return Err("Choose microphone, computer audio, or both.".into()); }
    let (exe, py) = sidecar(&app)?;
    let root = app.path().resource_dir().map_err(|e| e.to_string())?;
    let library = library()?;
    let state = app.path().app_data_dir().map_err(|e| e.to_string())?.join("transcription");
    fs::create_dir_all(&state).map_err(|e| e.to_string())?;
    let events = state.join("events.jsonl"); let stop = state.join("stop");
    let slot = TRANSCRIBER.get_or_init(|| Mutex::new(None));
    let mut guard = slot.lock().map_err(|e| e.to_string())?;
    if let Some(mut old) = guard.take() {
        if old.try_wait().map_err(|e| e.to_string())?.is_none() {
            *guard = Some(old);
            return Err("A transcript session is already running.".into());
        }
    }
    let child = Command::new(exe).arg(py.join("transcribe_worker.py")).arg(root).arg(library).arg(&events).arg(&stop)
        .env("FLOWDESK_AUDIO_SOURCE", audio).env("FLOWDESK_LANGUAGE", language)
        .stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn().map_err(|e| format!("Could not start local transcription: {e}"))?;
    *guard = Some(child);
    Ok(())
}

#[tauri::command]
pub fn capture_transcript_stop(app: AppHandle) -> Result<(), String> {
    let state = app.path().app_data_dir().map_err(|e| e.to_string())?.join("transcription");
    fs::create_dir_all(&state).map_err(|e| e.to_string())?;
    fs::write(state.join("stop"), b"stop").map_err(|e| e.to_string())
}

#[tauri::command]
pub fn capture_transcript_events(app: AppHandle) -> Result<Vec<serde_json::Value>, String> {
    let state = app.path().app_data_dir().map_err(|e| e.to_string())?.join("transcription");
    let path = state.join("events.jsonl");
    if !path.is_file() { return Ok(Vec::new()); }
    let contents = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut out = Vec::new();
    for line in contents.lines().rev().take(100).collect::<Vec<_>>().into_iter().rev() {
        if let Ok(value) = serde_json::from_str(&line) { out.push(value); }
    }
    Ok(out)
}

#[tauri::command]
pub fn capture_init() -> Result<String, String> { Ok(library()?.to_string_lossy().into_owned()) }

#[tauri::command]
pub fn capture_screenshot(app: AppHandle, full: bool) -> Result<(), String> { launch(&app, &[if full { "-PrintScreen" } else { "-RectangleRegion" }]) }

#[tauri::command]
pub fn capture_edit(app: AppHandle, path: String) -> Result<(), String> {
    let root = library()?;
    let candidate = PathBuf::from(path).canonicalize().map_err(|e| e.to_string())?;
    if !candidate.starts_with(&root) { return Err("Only images in the FlowDesk library can be edited here.".into()); }
    let candidate = candidate.to_string_lossy().to_string();
    launch(&app, &["-ImageEditor", &candidate])
}

#[tauri::command]
pub fn capture_record(app: AppHandle, audio: String) -> Result<(), String> {
    if !["silent", "computer", "microphone", "both"].contains(&audio.as_str()) { return Err("Choose a supported audio source.".into()); }
    launch(&app, &["-FlowDeskAudio", &audio, "-ScreenRecorder"])
}

#[tauri::command]
pub fn capture_stop(app: AppHandle) -> Result<(), String> { launch(&app, &["-FlowDeskStop"]) }

#[tauri::command]
pub fn capture_list() -> Result<Vec<CaptureItem>, String> {
    let root = library()?;
    let mut out = Vec::new();
    for folder in ["Captures", "Transcripts", "Imported"] {
        let mut stack = vec![root.join(folder)];
        while let Some(dir) = stack.pop() {
        let entries = fs::read_dir(dir).map_err(|e| e.to_string())?;
        for entry in entries.flatten() {
            let path = entry.path();
            let file_type = entry.file_type().map_err(|e| e.to_string())?;
            if file_type.is_dir() { stack.push(path); continue; }
            if !file_type.is_file() || path.file_name().and_then(|n| n.to_str()).unwrap_or("").contains("-recording-") { continue; }
            let kind = match path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase().as_str() {
                "png" | "jpg" | "jpeg" | "bmp" | "gif" | "tif" | "tiff" => "image",
                "mp4" | "webm" | "mkv" | "avi" | "mov" | "m4v" => "video",
                "txt" => "transcript", _ => continue,
            };
            let metadata = entry.metadata().map_err(|e| e.to_string())?;
            if metadata.len() == 0 { continue; }
            out.push(CaptureItem { name: path.file_name().unwrap_or_default().to_string_lossy().into_owned(), path: path.to_string_lossy().into_owned(), kind: kind.into(), modified: metadata.modified().ok().and_then(|x| x.duration_since(std::time::UNIX_EPOCH).ok()).map_or(0, |x| x.as_secs()), size: metadata.len() });
        }
        }
    }
    out.sort_by(|a,b| b.modified.cmp(&a.modified));
    Ok(out)
}

#[tauri::command]
pub fn capture_open(path: String) -> Result<(), String> {
    let root = library()?;
    let candidate = PathBuf::from(path).canonicalize().map_err(|e| e.to_string())?;
    if !candidate.starts_with(&root) { return Err("Only items in the FlowDesk library can be opened here.".into()); }
    Command::new("explorer.exe").arg(candidate).spawn().map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn capture_read_text(path: String) -> Result<String, String> {
    let root = library()?;
    let candidate = PathBuf::from(path).canonicalize().map_err(|e| e.to_string())?;
    if !candidate.starts_with(&root) || candidate.extension().and_then(|x| x.to_str()) != Some("txt") { return Err("Only transcript text files in the FlowDesk library can be read.".into()); }
    fs::read_to_string(candidate).map_err(|e| e.to_string())
}

#[tauri::command]
pub fn capture_open_folder() -> Result<(), String> { Command::new("explorer.exe").arg(library()?).spawn().map_err(|e| e.to_string())?; Ok(()) }
