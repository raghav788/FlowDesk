"""Local playback capture and bounded, serialized incremental transcription."""
import queue
import threading
import time
from pathlib import Path
import numpy as np
import av
import pyaudiowpatch as pa


def resample_audio(audio, rate):
    audio = np.ascontiguousarray(audio, dtype=np.float32)
    if rate == 16000:
        return audio
    frame = av.AudioFrame.from_ndarray(audio.reshape(1, -1), format='flt', layout='mono')
    frame.sample_rate = rate
    converter = av.AudioResampler(format='flt', layout='mono', rate=16000)
    frames = converter.resample(frame) + converter.resample(None)
    return np.concatenate([f.to_ndarray().ravel() for f in frames]) if frames else np.array([], dtype=np.float32)


class Chunker:
    """Prefer a pause boundary; never retain more than six seconds of source audio."""
    def __init__(self, rate):
        self.rate = rate
        self.parts = []
        self.count = 0
        self.elapsed = 0
        self.silence = 0
        self.voiced = False

    def feed(self, audio):
        if not len(audio):
            return None
        self.parts.append(audio)
        self.count += len(audio)
        rms = float(np.sqrt(np.mean(audio * audio)))
        if rms >= .003:
            self.voiced = True
            self.silence = 0
        else:
            self.silence += len(audio)
        duration = self.count / self.rate
        if duration >= 6 or (duration >= 1.5 and self.silence / self.rate >= .5):
            return self.flush()
        return None

    def flush(self):
        start = self.elapsed / self.rate
        self.elapsed += self.count
        audio = np.concatenate(self.parts) if self.parts else np.array([], dtype=np.float32)
        voiced = self.voiced
        self.parts, self.count, self.silence, self.voiced = [], 0, 0, False
        return (start, audio) if voiced and len(audio) >= self.rate * .3 else None


def playback_devices():
    p = pa.PyAudio()
    try:
        devices = list(p.get_loopback_device_info_generator())
        try:
            default = p.get_default_wasapi_loopback()['index']
        except (OSError, ValueError):
            default = None
        return [(int(d['index']), d['name']) for d in devices], default
    finally:
        p.terminate()


class LiveSession:
    def __init__(self, model, events, device, include_mic=False, language=None, replacements=None):
        self.model, self.events = model, events
        self.device, self.include_mic = device, include_mic
        self.language, self.replacements = language, replacements or {}
        self.stop_requested = threading.Event()
        self.capture_done = threading.Event()
        self.jobs_done = threading.Event()
        self.discard = threading.Event()
        self.raw = queue.Queue(maxsize=200)
        self.jobs = queue.Queue(maxsize=6)
        self.formats = {}
        self.started = time.monotonic()
        self.raw_overflow = False
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self, discard=False):
        if discard:
            self.discard.set()
        self.stop_requested.set()

    def _callback(self, label):
        def callback(data, frames, timing, status):
            if self.stop_requested.is_set():
                return None, pa.paComplete
            try:
                self.raw.put_nowait((label, data, status))
            except queue.Full:
                self.raw_overflow = True
                self.stop_requested.set()
            return None, pa.paContinue
        return callback

    def _submit(self, label, result):
        if result is None or self.discard.is_set():
            return
        start, audio = result
        rate, _ = self.formats[label]
        try:
            self.jobs.put_nowait((label, start, resample_audio(audio, rate)))
        except queue.Full:
            self.events.put(('warning', f'{label}: {len(audio)/rate:.1f}s skipped because transcription fell behind. Try one audio source.'))

    def _collect(self):
        chunkers = {}
        try:
            while not self.capture_done.is_set() or not self.raw.empty():
                try:
                    label, data, status = self.raw.get(timeout=.1)
                except queue.Empty:
                    continue
                if self.discard.is_set():
                    continue
                rate, channels = self.formats[label]
                audio = np.frombuffer(data, dtype=np.float32).reshape(-1, channels).mean(axis=1)
                chunker = chunkers.setdefault(label, Chunker(rate))
                if status:
                    self.events.put(('warning', f'{label}: the audio driver reported an interruption; some sound may be missing.'))
                self._submit(label, chunker.feed(audio))
            if not self.discard.is_set():
                for label, chunker in chunkers.items():
                    self._submit(label, chunker.flush())
        except Exception as exc:
            self.events.put(('error', f'Audio processing: {exc}'))
            self.stop_requested.set()
        finally:
            self.jobs_done.set()

    def _infer(self):
        try:
            while not self.jobs_done.is_set() or not self.jobs.empty():
                try:
                    label, start, audio = self.jobs.get(timeout=.1)
                except queue.Empty:
                    continue
                if self.discard.is_set():
                    continue
                self.events.put(('processing', self.jobs.qsize()))
                segments, _ = self.model.transcribe(audio, language=self.language, beam_size=3,
                    vad_filter=True, condition_on_previous_text=False,
                    initial_prompt=', '.join(self.replacements.values()) or None)
                text = ' '.join(segment.text.strip() for segment in segments).strip()
                if text and not self.discard.is_set():
                    from core.text_utils import clean_text
                    self.events.put(('caption', (label, start, clean_text(text, self.replacements))))
        except Exception as exc:
            self.events.put(('error', f'Transcription: {exc}'))
            self.stop_requested.set()

    def _run(self):
        p, streams = None, []
        collector = threading.Thread(target=self._collect, daemon=True)
        inference = threading.Thread(target=self._infer, daemon=True)
        collector.start()
        inference.start()
        try:
            p = pa.PyAudio()
            if self.device is not None:
                index, expected_name = self.device
                device = p.get_device_info_by_index(index)
                if not device.get('isLoopbackDevice') or device['name'] != expected_name:
                    raise RuntimeError('Playback device changed. Stop, refresh devices, and select it again.')
                sources = [('Computer', device)]
            else:
                sources = []
            if self.include_mic:
                sources.append(('Microphone', p.get_default_input_device_info()))
            if not sources:
                raise RuntimeError('Choose a playback device or microphone.')
            for label, device in sources:
                rate = int(device['defaultSampleRate'])
                channels = min(2, int(device['maxInputChannels']))
                if channels < 1:
                    raise RuntimeError(f'{label} has no capture channels.')
                self.formats[label] = (rate, channels)
                stream = p.open(format=pa.paFloat32, channels=channels, rate=rate, input=True,
                    input_device_index=int(device['index']), frames_per_buffer=max(512, rate//10),
                    stream_callback=self._callback(label), start=False)
                streams.append(stream)
            for stream in streams:
                stream.start_stream()
            self.events.put(('listening', ' + '.join(label for label, _ in sources)))
            while not self.stop_requested.wait(.2):
                if any(not stream.is_active() for stream in streams):
                    raise RuntimeError('An audio device stopped. Check the output selected by your video/meeting and refresh devices.')
        except Exception as exc:
            self.events.put(('error', str(exc)))
        finally:
            self.stop_requested.set()
            for stream in streams:
                try:
                    stream.stop_stream()
                except Exception:
                    pass
                try:
                    stream.close()
                except Exception as exc:
                    self.events.put(('warning', f'Audio device close: {exc}'))
            if p is not None:
                try:
                    p.terminate()
                except Exception as exc:
                    self.events.put(('warning', f'Audio backend cleanup: {exc}'))
            self.capture_done.set()
            collector.join()
            inference.join()
            if self.raw_overflow:
                self.events.put(('warning', 'Audio capture fell behind and stopped. Some sound was lost; restart captions.'))
            self.events.put(('done', None))

