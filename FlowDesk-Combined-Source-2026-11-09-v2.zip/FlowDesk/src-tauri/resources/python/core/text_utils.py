import re

def clean_text(text, replacements=None):
    text = re.sub(r'\s+', ' ', text).strip()
    for wrong, right in (replacements or {}).items():
        if wrong.strip():
            text = re.sub(r'(?<!\w)' + re.escape(wrong) + r'(?!\w)', lambda _: right, text, flags=re.I)
    return text
