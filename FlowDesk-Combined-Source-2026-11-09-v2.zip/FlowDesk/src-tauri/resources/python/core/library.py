from dataclasses import dataclass
from pathlib import Path
from datetime import datetime
import json
import shutil
import uuid

IMAGES = {'.png','.jpg','.jpeg','.bmp','.tif','.tiff'}
VIDEOS = {'.mp4','.webm','.mkv','.avi','.gif','.mov','.m4v'}

def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    temporary.replace(path)

@dataclass(frozen=True)
class Asset:
    path: Path
    kind: str
    title: str
    modified: float
    size: int
    @property
    def key(self): return str(self.path)
    @property
    def signature(self): return (self.key,self.modified,self.size)

class Library:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.captures = self.root/'Captures'
        self.transcripts = self.root/'Transcripts'
        self._title_cache={}
        for folder in (self.captures,self.transcripts,self.root/'Imported'):
            folder.mkdir(parents=True,exist_ok=True)

    def scan(self):
        assets=[]
        for folder in (self.captures,self.transcripts,self.root/'Imported'):
            for path in folder.rglob('*'):
                try:
                    if not path.is_file() or path.is_symlink() or '-recording-' in path.name:
                        continue
                    suffix=path.suffix.lower()
                    kind='image' if suffix in IMAGES else 'video' if suffix in VIDEOS else 'transcript' if suffix=='.txt' else None
                    if kind is None: continue
                    stat=path.stat()
                    if not stat.st_size: continue
                    title=path.stem
                    meta=path.with_suffix('.session.json')
                    if kind=='transcript' and meta.is_file():
                        try:
                            stamp=meta.stat().st_mtime_ns
                            cached=self._title_cache.get(str(meta))
                            if cached and cached[0]==stamp:title=cached[1]
                            else:
                                title=json.loads(meta.read_text(encoding='utf8')).get('title',title)
                                self._title_cache[str(meta)]=(stamp,title)
                        except (OSError,ValueError): pass
                    assets.append(Asset(path,kind,title,stat.st_mtime,stat.st_size))
                except OSError:
                    continue
        return sorted(assets,key=lambda x:x.modified,reverse=True)

    def new_session(self, source, language, linked_recording=False):
        stamp=datetime.now().strftime('%Y-%m-%d %H.%M.%S')
        path=self.transcripts/f'{stamp} {uuid.uuid4().hex[:6]}.txt'
        doc={'schema':1,'id':uuid.uuid4().hex,'started':datetime.now().isoformat(),
            'source':source,'language':language,'linked_recording':linked_recording,
            'title':'Screen recording transcript' if linked_recording else 'New transcript',
            'blocks':[],'warnings':[],'complete':False}
        path.write_text(f'FlowDesk transcript\nStarted: {doc["started"]}\nSource: {source}\n\n',encoding='utf8')
        atomic_json(path.with_suffix('.session.json'),doc)
        return path,doc

    def append_caption(self,path,doc,source,seconds,text):
        stamp=f'{int(seconds)//3600:02}:{int(seconds)%3600//60:02}:{int(seconds)%60:02}'
        with Path(path).open('a',encoding='utf8') as out:
            out.write(f'[{stamp}] {source}\n{text}\n\n')
            out.flush()
        doc['blocks'].append({'source':source,'seconds':seconds,'text':text})
        if len(doc['blocks'])==1:
            doc['title']=text[:65].strip() or doc['title']
        atomic_json(Path(path).with_suffix('.session.json'),doc)

    def warning(self,path,doc,text):
        with Path(path).open('a',encoding='utf8') as out: out.write(f'[Notice] {text}\n\n')
        doc['warnings'].append(text)
        atomic_json(Path(path).with_suffix('.session.json'),doc)

    def finish(self,path,doc):
        doc.update(complete=True,finished=datetime.now().isoformat())
        atomic_json(Path(path).with_suffix('.session.json'),doc)

    def import_folder(self,source):
        source=Path(source).resolve()
        if source==self.root or self.root in source.parents:
            raise ValueError('That folder is already in the FlowDesk library.')
        count=0
        excluded={'python','qt','engines','site-packages','licenses','.git','__pycache__'}
        files=list(source.rglob('*'))
        for path in files:
            rel=path.relative_to(source)
            if path==self.root or self.root in path.parents: continue
            if not path.is_file() or path.is_symlink() or any(p.lower() in excluded for p in rel.parts): continue
            if path.suffix.lower() not in IMAGES|VIDEOS|{'.txt'}: continue
            if path.name.lower().startswith(('readme','license','third-party','requirements')): continue
            target=self.root/'Imported'/path.name
            n=2
            while target.exists():
                target=self.root/'Imported'/f'{path.stem} ({n}){path.suffix}'
                n+=1
            shutil.copy2(path,target)
            count+=1
        return count
