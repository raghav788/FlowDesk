import queue
import threading
from pathlib import Path
from faster_whisper import WhisperModel
from core.live_audio import LiveSession, playback_devices

class SpeechEngine:
    def __init__(self,root,library,events):
        self.root=Path(root)
        self.library=library
        self.events=events
        self.model=None
        self.session=None
        self.session_events=queue.Queue()
        self.path=None
        self.doc=None
        self.words=[]
        self.auto_video=False
        self.source=''

    def load(self):
        def run():
            try:
                model=self.root/'models'/'base'
                if not (model/'model.bin').is_file(): raise RuntimeError('Speech model missing. Extract the complete FlowDesk ZIP.')
                import os
                self.model=WhisperModel(str(model),device='cpu',compute_type='int8',local_files_only=True,
                    cpu_threads=max(1,min(4,(os.cpu_count() or 2)-1)))
                self.events.put(('model_ready',None))
            except Exception as error: self.events.put(('model_error',str(error)))
        threading.Thread(target=run,daemon=True).start()

    def devices(self):
        def run():
            try: self.events.put(('devices',playback_devices()))
            except Exception as error: self.events.put(('devices_error',str(error)))
        threading.Thread(target=run,daemon=True).start()


    def start(self,source,device,language,auto_video=False):
        if self.session: raise RuntimeError('A transcript is already running.')
        if self.model is None: raise RuntimeError('The local speech model is still loading.')
        selected=None if source=='microphone' else device
        if source!='microphone' and selected is None: raise RuntimeError('Select a playback device for computer audio.')
        self.path,self.doc=self.library.new_session(source,language,auto_video)
        self.words=[]
        self.source=source
        self.auto_video=auto_video
        self.session_events=queue.Queue()
        self.session=LiveSession(self.model,self.session_events,selected,source in ('microphone','both'),language)
        self.session.start()
        return self.path

    def stop(self):
        if self.session: self.session.stop()

    def poll(self):
        events=[]
        while True:
            try: kind,value=self.session_events.get_nowait()
            except queue.Empty: break
            try:
                if kind=='caption':
                    source,seconds,text=value
                    self.library.append_caption(self.path,self.doc,source,seconds,text)
                    self.words.append(text)
                elif kind in ('warning','error'):
                    self.library.warning(self.path,self.doc,str(value))
                elif kind=='done':
                    self.library.finish(self.path,self.doc)
                    self.session=None
                events.append((kind,value))
            except OSError as error:
                self.stop()
                events.append(('save_error',f'Transcript could not be saved: {error}. Audio capture is stopping.'))
                if kind=='done':
                    self.session=None
                    events.append(('done',None))
        return events
