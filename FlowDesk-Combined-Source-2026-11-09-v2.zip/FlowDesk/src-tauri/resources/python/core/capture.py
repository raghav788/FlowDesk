import json
import os
from pathlib import Path
import subprocess
import time

class CaptureEngine:
    def __init__(self,folder,library):
        self.folder=Path(folder)
        self.exe=self.folder/'CaptureFlow.exe'
        self.journal=self.folder/'FlowDesk.bridge.jsonl'
        self.offset=0
        self.buffer=b''
        self.state='starting'
        self.process=None
        self.children=[]
        self.start_time=time.monotonic()
        self.library=library

    def configure(self):
        if not self.exe.is_file(): raise RuntimeError('The capture engine is missing. Extract the complete FlowDesk ZIP.')
        folder=self.folder/'FlowDesk Capture'
        folder.mkdir(parents=True,exist_ok=True)
        path=folder/'ApplicationConfig.json'
        try: config=json.loads(path.read_text(encoding='utf8'))
        except (OSError,ValueError): config={}
        config.update(ShowStartScreen=False,DisableHotkeys=True,ShowTray=False,SilentRun=True,
            AutoCheckUpdate=False,DisableUpload=True,UseCustomScreenshotsPath=True,
            CustomScreenshotsPath=str(self.library.captures),CustomScreenshotsPath2='')
        config['ThemeOptions']={'Theme':'Light','UseSystemTheme':False,'AccentColorHex':'#3D6950','UseSystemAccentColor':False}
        task=config.setdefault('DefaultTaskSettings',{})
        task['AfterCaptureJob']=256
        task.setdefault('GeneralSettings',{}).update(ShowToastNotificationAfterTaskCompleted=False)
        task.setdefault('CaptureSettings',{}).update(ScreenRecordUseNative=True,ScreenRecordShowBar=False,
            ScreenRecordSystemAudio=True,ScreenRecordMicrophone=False,ScreenRecordRequireHardwareEncoder=False,
            ScreenRecordFPS=30,ScreenRecordShowTimer=True,ScreenRecordShowButtonLabels=True)
        path.write_text(json.dumps(config,indent=2),encoding='utf8')

    def start(self):
        self.configure()
        self.offset=self.journal.stat().st_size if self.journal.exists() else 0
        self.process=self.command('-silent','-FlowDeskParent',str(os.getpid()))

    def command(self,*args):
        child=subprocess.Popen([str(self.exe),*map(str,args)],cwd=self.folder,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.children=[p for p in self.children if p.poll() is None]
        self.children.append(child)
        return child

    def poll(self):
        events=[]
        if self.journal.exists():
            size=self.journal.stat().st_size
            if size<self.offset: self.offset=0; self.buffer=b''
            with self.journal.open('rb') as file:
                file.seek(self.offset)
                data=file.read()
                self.offset=file.tell()
            lines=(self.buffer+data).split(b'\n')
            self.buffer=lines.pop()
            for line in lines:
                try:
                    event=json.loads(line.decode('utf-8-sig'))
                    self.state=event['status']
                    events.append(event)
                except (ValueError,UnicodeError,KeyError): continue
        return events

    def screenshot(self,full=False): return self.command('-PrintScreen' if full else '-RectangleRegion')
    def record(self,audio,device=None):
        args=['-FlowDeskAudio',audio]
        if device is not None and audio in ('computer','both'):
            args.extend(['-FlowDeskPlayback',device[1].removesuffix(' [Loopback]')])
        return self.command(*args,'-ScreenRecorder')
    def stop(self): return self.command('-FlowDeskStop')
    def edit(self,path): return self.command('-ImageEditor',str(path))
    def shutdown(self): return self.command('-FlowDeskExit')
