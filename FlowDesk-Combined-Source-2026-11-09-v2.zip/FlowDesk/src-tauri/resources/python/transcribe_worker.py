"""FlowDesk local live transcription sidecar. Uses bundled faster-whisper and WASAPI capture."""
import json
import os
import queue
import sys
import time
from pathlib import Path

root = Path(sys.argv[1]).resolve()
library_path = Path(sys.argv[2]).resolve()
events_path = Path(sys.argv[3]).resolve()
stop_path = Path(sys.argv[4]).resolve()
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core.library import Library
from core.speech import SpeechEngine
from core.live_audio import playback_devices

def send(kind, value=None):
    with events_path.open('a', encoding='utf-8') as f:
        f.write(json.dumps({'kind': kind, 'value': value}, ensure_ascii=False) + '\n')

def main():
    for p in (events_path, stop_path):
        try: p.unlink()
        except FileNotFoundError: pass
    library = Library(library_path)
    engine = SpeechEngine(root, library, __import__('queue').Queue())
    engine.load()
    send('state', 'loading-model')
    while engine.model is None:
        try:
            kind, value = engine.events.get(timeout=.25)
            if kind == 'model_error':
                send('error', value); return 2
        except queue.Empty: pass
    devices, default = playback_devices()
    send('devices', {'devices': devices, 'default': default})
    source = os.environ.get('FLOWDESK_AUDIO_SOURCE', 'computer')
    language = os.environ.get('FLOWDESK_LANGUAGE', 'auto')
    device = next((d for d in devices if d[0] == default), devices[0] if devices else None)
    if source != 'microphone' and device is None:
        send('error', 'No WASAPI playback loopback device is available.'); return 3
    try:
        engine.start(source, device, None if language == 'auto' else language, auto_video=True)
        send('state', 'listening')
    except Exception as error:
        send('error', str(error)); return 4
    while not stop_path.exists():
        for kind, value in engine.poll(): send(kind, value)
        time.sleep(.2)
    engine.stop()
    while engine.session is not None:
        for kind, value in engine.poll(): send(kind, value)
        time.sleep(.1)
    send('state', 'done')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
