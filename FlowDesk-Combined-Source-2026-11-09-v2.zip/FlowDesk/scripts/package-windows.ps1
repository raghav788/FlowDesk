param(
  [Parameter(Mandatory=$true)][string]$DotNet,
  [Parameter(Mandatory=$true)][string]$PythonRuntime,
  [Parameter(Mandatory=$true)][string]$WhisperModel,
  [string]$Configuration = 'Release'
)
$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$src = Join-Path $repo 'integrations\CaptureFlow-Source'
$res = Join-Path $repo 'src-tauri\resources'
$captureOut = Join-Path $res 'capture'
$pythonOut = Join-Path $res 'python\python-runtime'
$modelsParent = Join-Path $res 'models'
$modelsOut = Join-Path $modelsParent 'base'
New-Item -ItemType Directory -Force -Path $captureOut,(Split-Path $pythonOut -Parent),$modelsParent | Out-Null
& $DotNet publish (Join-Path $src 'ShareX\ShareX\ShareX.csproj') -c $Configuration -p:Platform=x64 -r win-x64 --self-contained true -p:CaptureFlowFlavor=FlowDeskWin10 -p:BuildInParallel=false -p:UseSharedCompilation=false -m:1 -o $captureOut
if ($LASTEXITCODE -ne 0) { throw "CaptureFlow publish failed: $LASTEXITCODE" }
Get-ChildItem $captureOut -Filter '*.pdb' -File -Recurse | Remove-Item -Force
Get-ChildItem $captureOut -Directory | Where-Object Name -ne 'en-US' | Remove-Item -Force -Recurse
if (Test-Path $pythonOut) { Remove-Item $pythonOut -Recurse -Force }
Copy-Item -LiteralPath $PythonRuntime -Destination $pythonOut -Recurse
$site = Join-Path $pythonOut 'Lib\site-packages'
Get-ChildItem $site -Force -ErrorAction SilentlyContinue | Where-Object Name -Match '^(PySide6|PySide6-|shiboken6|shiboken6-)' | Remove-Item -Force -Recurse
Get-ChildItem (Join-Path $pythonOut 'Scripts') -Force -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse
$sourceModel = (Resolve-Path -LiteralPath $WhisperModel).Path
$targetModel = [System.IO.Path]::GetFullPath($modelsOut)
if ($sourceModel -ne $targetModel) {
  if (Test-Path $modelsOut) { Remove-Item $modelsOut -Recurse -Force }
  Copy-Item -LiteralPath $sourceModel -Destination $modelsOut -Recurse
}
Write-Host 'Windows resources are ready under src-tauri/resources. Build the app with: npm run tauri build'
