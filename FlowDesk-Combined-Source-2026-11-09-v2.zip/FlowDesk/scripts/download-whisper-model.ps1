param([string]$Destination = 'src-tauri\resources\models\base')
$ErrorActionPreference = 'Stop'
$repo = Split-Path $PSScriptRoot -Parent
$destinationPath = Join-Path $repo $Destination
New-Item -ItemType Directory -Force -Path $destinationPath | Out-Null
$base = 'https://huggingface.co/Systran/faster-whisper-base/resolve/main'
foreach ($name in @('config.json','model.bin','tokenizer.json','vocabulary.txt')) {
  Invoke-WebRequest -Uri "$base/$name?download=true" -OutFile (Join-Path $destinationPath $name)
}
