# Third-party notices

## Krovi

FlowDesk's panel shell, Svelte UI, Tauri backend, and productivity features are derived from Krovi by Naitik Sahu and contributors, https://github.com/nAItiklearn/krovi. Krovi is MIT licensed. Its original `LICENSE` is retained in this repository. The FlowDesk product name and the Capture view are added in this fork.

## ShareX capture engine

The screen capture and recording helper is derived from ShareX, Copyright (c) 2007-2026 ShareX Team, and is licensed under GPL-3.0-or-later. The complete modified source is in `integrations/CaptureFlow-Source`; its original license is included there. The helper is a separate executable launched by FlowDesk.

## FlowDesk local transcription

The Python local transcription backend is derived from the earlier FlowDesk application. It uses faster-whisper, CTranslate2, PyAV, NumPy, and PyAudioWPatch. Their license and attribution files are retained in the Python runtime distributed with Windows builds. Whisper model weights are separately licensed; see their model card and source before redistributing.

## Icons

The included Lucide icon paths are ISC licensed by Lucide Contributors. Source attribution is present in `src/lib/icons.ts`.
