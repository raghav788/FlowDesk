<script lang="ts">
  import { onMount } from 'svelte';
  import { invoke, isTauri } from '../lib/bridge';
  import Icon from '../components/Icon.svelte';
  import { convertFileSrc } from '@tauri-apps/api/core';

  type Item = { name: string; path: string; kind: 'image' | 'video' | 'transcript'; modified: number; size: number };
  let items = $state<Item[]>([]);
  let library = $state('Documents/FlowDesk Library');
  let selected = $state<Item | null>(null);
  let filter = $state('all');
  let audio = $state('computer');
  let busy = $state(false);
  let recording = $state(false);
  let transcribing = $state(false);
  let liveCaption = $state('');
  let message = $state('');
  let transcript = $state('');
  let query = $state('');
  let loading = $state(true);
  let refreshTimer: ReturnType<typeof setInterval> | undefined;

  const visible = $derived(items.filter((x) => (filter === 'all' || x.kind === filter) && x.name.toLowerCase().includes(query.trim().toLowerCase())));
  const when = (s: number) => new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(s * 1000));
  const size = (n: number) => n > 1_000_000 ? `${(n / 1_000_000).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1000))} KB`;

  async function refresh() {
    if (!isTauri()) return;
    try { items = await invoke<Item[]>('capture_list'); }
    catch (e) { message = String(e); }
    finally { loading = false; }
  }
  async function action(cmd: string, args?: Record<string, unknown>, success = 'Saved to your library') {
    busy = true; message = '';
    try { await invoke(cmd, args); message = success; await refresh(); return true; }
    catch (e) { message = String(e); return false; }
    finally { busy = false; }
  }
  async function select(item: Item) {
    selected = item; transcript = '';
    if (item.kind === 'transcript') {
      try { transcript = await invoke<string>('capture_read_text', { path: item.path }); }
      catch (e) { message = String(e); }
    }
  }
  async function openSelected() {
    if (selected) await action('capture_open', { path: selected.path });
  }
  async function startTranscript() {
    liveCaption = '';
    transcribing = await action('capture_transcript_start', { audio, language: 'auto' }, 'Listening on this device');
  }
  async function stopTranscript() { await action('capture_transcript_stop', undefined, 'Transcript saved'); transcribing = false; liveCaption = ''; await refresh(); }
  async function pollTranscript() {
    if (!transcribing || !isTauri()) return;
    try {
      const events = await invoke<{kind:string;value:unknown}[]>('capture_transcript_events');
      for (const event of events) {
        if (event.kind === 'caption' && Array.isArray(event.value)) liveCaption = String(event.value[2] ?? '');
        else if (event.kind === 'error' || event.kind === 'save_error') message = String(event.value ?? 'Transcription stopped.');
        else if (event.kind === 'done' || (event.kind === 'state' && event.value === 'done')) { transcribing = false; await refresh(); }
      }
    } catch (e) { message = String(e); }
  }
  onMount(() => {
    if (isTauri()) {
      void invoke<string>('capture_init').then((p) => (library = p));
      void refresh(); refreshTimer = setInterval(() => { void refresh(); void pollTranscript(); }, 1000);
    }
    return () => { if (refreshTimer) clearInterval(refreshTimer); };
  });
</script>

<section class="capture">
  <div class="top">
    <div><h1>Capture</h1><p class="sub">Screenshots, recordings and transcripts, saved on this device.</p></div>
    <button class="folder" onclick={() => void action('capture_open_folder', undefined, 'Capture folder opened')}><Icon name="folder" size={15} /> Open library</button>
  </div>

  <div class="actions">
    <button class="primary" disabled={busy || !isTauri()} onclick={() => void action('capture_screenshot', { full: false }, 'Screenshot saved')}><Icon name="capture" size={16} /> Select area <kbd>Ctrl</kbd><kbd>Alt</kbd><kbd>S</kbd></button>
    <button class="secondary" disabled={busy || recording || !isTauri()} onclick={async () => { recording = await action('capture_record', { audio }, 'Screen recording started'); }}><Icon name="play" size={14} /> Record screen</button>
    {#if recording}<button class="stop" disabled={busy} onclick={async () => { await action('capture_stop', undefined, 'Recording saved'); recording = false; }}><Icon name="square" size={13} /> Stop recording</button>{/if}
    <label class="audio"><Icon name="volume" size={14} /> Audio <select bind:value={audio} aria-label="Recording audio source"><option value="computer">Computer</option><option value="microphone">Microphone</option><option value="both">Both</option><option value="silent">Silent</option></select></label>
  </div>
  <div class="transcribe" class:live={transcribing}>
    <div class="live-icon"><Icon name={transcribing ? 'activity' : 'mic'} size={18} /></div>
    <div class="live-copy"><strong>Live transcription <span class="local-pill"><Icon name="lock" size={11} /> On-device</span></strong><span>{transcribing ? (liveCaption || 'Listening for speech…') : 'Turn speech into searchable notes as you work.'}</span></div>
    {#if transcribing}<button class="stop" disabled={busy} onclick={() => void stopTranscript()}><Icon name="square" size={13} /> Finish transcript</button>
    {:else}<button class="secondary" disabled={busy || !isTauri()} onclick={() => void startTranscript()}><Icon name="mic" size={15} /> Start listening</button>{/if}
  </div>

  <div class="library-head"><div><div><strong>Library</strong><span class="count">{visible.length}</span></div><label class="search"><Icon name="search" size={14} /><input bind:value={query} placeholder="Search captures" aria-label="Search saved captures" /></label></div>
    <div class="filters" aria-label="Filter saved items">{#each ['all', 'image', 'video', 'transcript'] as f}<button class:chosen={filter === f} aria-pressed={filter === f} onclick={() => (filter = f)}>{f === 'all' ? 'All' : f === 'image' ? 'Images' : f === 'video' ? 'Videos' : 'Transcripts'}</button>{/each}</div>
  </div>

  <div class="content">
    <div class="list">
      {#if !isTauri()}<div class="empty"><span class="empty-icon"><Icon name="monitor" size={22} /></span><strong>Open FlowDesk on Windows</strong><span>Your local captures will appear in this library.</span></div>
      {:else if loading}<div class="empty"><Icon name="loader" size={18} /> Loading your library…</div>
      {:else if visible.length === 0}<div class="empty"><span class="empty-icon"><Icon name="inbox" size={22} /></span><strong>{query ? 'No matching captures' : 'Nothing here yet'}</strong><span>{query ? 'Try another name or clear your search.' : 'Your screenshots, recordings and transcripts will show up here.'}</span></div>
      {:else}{#each visible as item (item.path)}<button class="item" class:active={selected?.path === item.path} aria-current={selected?.path === item.path ? 'true' : undefined} onclick={() => void select(item)}>
        <span class="kind"><Icon name={item.kind === 'image' ? 'capture' : item.kind === 'video' ? 'play' : 'notes'} size={16} /></span><span class="itemtext"><strong>{item.name}</strong><small>{when(item.modified)} · {size(item.size)}</small></span>
      </button>{/each}{/if}
    </div>
    <div class="preview">
      {#if selected}
        <div class="preview-head"><strong>{selected.name}</strong><button class="folder" onclick={() => void openSelected()}><Icon name="externalLink" size={14} /> Open</button></div>
        {#if selected.kind === 'transcript'}<pre>{transcript || 'Loading transcript…'}</pre>
        {:else if selected.kind === 'image'}<div class="media-preview"><img src={convertFileSrc(selected.path)} alt={selected.name} /><button class="folder" onclick={() => void action('capture_edit', { path: selected!.path })}><Icon name="pencil" size={14} /> Edit image</button></div>
        {:else}<div class="media-preview"><!-- svelte-ignore a11y_media_has_caption --><video src={convertFileSrc(selected.path)} controls playsinline aria-label={selected.name}></video><button class="folder" onclick={() => void openSelected()}><Icon name="externalLink" size={14} /> Open video</button></div>{/if}
      {:else}<div class="preview-placeholder"><span class="empty-icon"><Icon name="image" size={24} /></span><strong>Preview</strong><span>Choose something from your library to see it here.</span></div>{/if}
    </div>
  </div>
  <footer><span><Icon name="folder" size={12} /> {library}</span><span role="status" aria-live="polite">{message}</span></footer>
</section>

<style>
  .capture{height:100%;min-height:0;display:flex;flex-direction:column;padding:24px 28px 14px;gap:15px;color:var(--text);font-size:12px}
  .top{display:flex;justify-content:space-between;align-items:center;gap:12px}h1{font-size:24px;letter-spacing:-.045em;margin:0 0 3px;font-family:var(--font-display)}.sub{margin:0;color:var(--text-2);font-size:11px}
  button{font:inherit;cursor:pointer;transition:background .16s,border-color .16s,transform .16s}button:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--accent);outline-offset:2px}button:disabled{opacity:.48;cursor:not-allowed}.folder,.secondary,.stop,.primary{border:1px solid var(--line);border-radius:10px;padding:8px 11px;display:flex;gap:7px;align-items:center;color:var(--text);background:var(--surface-2);font-size:11px;white-space:nowrap}.folder:hover,.secondary:hover{background:var(--surface-3);border-color:var(--line-strong)}.primary{background:var(--accent);color:var(--accent-ink);border-color:transparent}.primary:hover{filter:brightness(1.08)}.stop{color:var(--danger);border-color:color-mix(in srgb,var(--danger) 35%,var(--line));background:color-mix(in srgb,var(--danger) 8%,var(--surface-1))}.actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.actions kbd{font:9px var(--font-mono);padding:2px 4px;border-radius:4px;background:var(--surface-1);color:inherit}.audio{margin-left:auto;color:var(--text-2);display:flex;align-items:center;gap:7px}select{background:var(--surface-2);border:1px solid var(--line);border-radius:8px;padding:7px;color:var(--text);font-size:11px}
  .transcribe{border:1px solid var(--line);background:linear-gradient(110deg,var(--surface-2),var(--surface-1) 65%);border-radius:14px;padding:13px 14px;display:flex;align-items:center;gap:11px;min-height:54px}.transcribe.live{border-color:color-mix(in srgb,var(--accent) 45%,var(--line));box-shadow:0 0 0 1px color-mix(in srgb,var(--accent) 12%,transparent)}.live-icon{display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:color-mix(in srgb,var(--accent) 14%,var(--surface-1));color:var(--accent);flex:none}.live-copy{min-width:0;flex:1}.live-copy strong{display:flex;align-items:center;gap:8px;font-size:11px}.live-copy>span{display:block;font-size:10px;color:var(--text-2);margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.local-pill{display:inline-flex;align-items:center;gap:3px;font-size:9px;color:var(--text-2);font-weight:500;border:1px solid var(--line);border-radius:20px;padding:2px 6px}
  .library-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.library-head>div:first-child{display:flex;align-items:center;gap:14px}.library-head>div:first-child>div{display:flex;align-items:center;gap:8px}.count{border-radius:10px;background:var(--surface-3);padding:3px 7px;font-size:10px;color:var(--text-2)}.search{display:flex;align-items:center;gap:7px;border:1px solid var(--line);background:var(--surface-1);border-radius:9px;padding:6px 9px;color:var(--text-3)}.search input{width:150px;border:0;outline:0;background:transparent;color:var(--text);font:10px var(--font)}.search input::placeholder{color:var(--text-3)}.filters{display:flex;gap:3px;padding:3px;border-radius:9px;background:var(--surface-1)}.filters button{padding:5px 8px;border-radius:7px;color:var(--text-2);font-size:10px;background:transparent}.filters button:hover{background:var(--surface-2);color:var(--text)}.filters .chosen{background:var(--surface-3);color:var(--text)}
  .content{display:grid;grid-template-columns:minmax(220px,.82fr) minmax(0,1.18fr);gap:12px;min-height:0;flex:1}.list,.preview{border:1px solid var(--line);border-radius:13px;background:var(--surface-1);min-height:0;overflow:auto}.item{width:100%;display:flex;gap:10px;align-items:center;text-align:left;padding:9px 11px;border:0;border-bottom:1px solid var(--line);color:var(--text);background:transparent}.item:hover,.item.active{background:var(--surface-2)}.item.active{box-shadow:inset 2px 0 var(--accent)}.kind{width:32px;height:32px;display:grid;place-items:center;border-radius:9px;background:var(--surface-3);flex:none;color:var(--text-2)}.itemtext{min-width:0}.itemtext strong{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px}.itemtext small{display:block;color:var(--text-3);font-size:9px;margin-top:3px}.preview-head{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:9px 11px;border-bottom:1px solid var(--line)}.preview-head strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.preview pre{white-space:pre-wrap;overflow:auto;padding:13px;margin:0;font:11px/1.6 var(--font-mono);user-select:text;color:var(--text-2)}.preview-placeholder,.empty{height:100%;min-height:115px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;color:var(--text-2);font-size:10px}.preview-placeholder strong,.empty strong{color:var(--text);font-size:11px}.preview-placeholder>span:last-child,.empty>span:last-child{max-width:230px;text-align:center;line-height:1.5}.empty-icon{display:grid;place-items:center;width:42px;height:42px;margin-bottom:3px;border-radius:13px;background:var(--surface-2);color:var(--text-2)}.media-preview{height:calc(100% - 42px);padding:10px;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px}.media-preview img,.media-preview video{max-width:100%;max-height:calc(100% - 38px);object-fit:contain;border-radius:7px}.empty{padding:20px;text-align:center}footer{display:flex;justify-content:space-between;align-items:center;gap:12px;color:var(--text-3);font-size:9px}footer span:first-child{display:flex;align-items:center;gap:5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}footer span:last-child{text-align:right;max-width:50%}
  @media(max-width:760px){.capture{padding:18px 16px 12px}.content{grid-template-columns:minmax(150px,.85fr) minmax(0,1.15fr)}.library-head{align-items:flex-start;flex-direction:column}.search input{width:110px}.audio{margin-left:0}}
</style>
